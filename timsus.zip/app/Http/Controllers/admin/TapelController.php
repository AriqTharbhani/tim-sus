<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Tapel;
use Illuminate\Http\Request;

class TapelController extends Controller
{
    public function indexTapel()
    {
    $title = 'Data Tapel';
    $title_menu = 'Menu Data Tapel';
    $data_tapel = Tapel::all();
    return view('admin.tapel.index', compact('title','title_menu','data_tapel'));
    }
}
