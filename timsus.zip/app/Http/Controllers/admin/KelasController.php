<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Kelas;
use Illuminate\Http\Request;

class KelasController extends Controller
{
    public function indexKelas()
{
    $title = 'Data kelas';
    $title_menu = 'Menu Data kelas';
    $data_kelas = Kelas::get();
    
    return view('admin.kelas.index', compact('title', 'title_menu', 'data_kelas'));
}
}
