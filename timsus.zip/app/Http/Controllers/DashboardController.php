<?php

namespace App\Http\Controllers;

// use App\Models\Guru;
use App\Models\User;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function indexAdmin() {
        $jumlah_user = User::count();
        // $jumlah_guru = Guru::count();
        return view('dashboard.admin');
        // compact('jumlah_user','jumlah_guru')
    }

    public function indexGuru() {
        return view('dashboard.guru');
    }

    public function indexSiswa() {
        return view('dashboard.siswa');
    }
}